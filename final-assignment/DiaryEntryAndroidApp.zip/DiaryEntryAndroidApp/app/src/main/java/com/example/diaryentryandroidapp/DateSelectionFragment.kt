package com.example.diaryentryandroidapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2

class DateSelectionFragment : Fragment() {
    lateinit var viewModel: MyViewModel
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        viewModel = activity?.run {
            ViewModelProvider(this)[MyViewModel::class.java]
        } ?: throw Exception("Invalid Activity")
        val view = inflater.inflate(R.layout.date_selection_fragment, container, false)
        val datePicker = view.findViewById<DatePicker>(R.id.datePicker)
        val nextButton = view.findViewById<Button>(R.id.nextButton)

        nextButton.setOnClickListener {
            val day = datePicker.dayOfMonth
            val month = datePicker.month + 1 // +1 because months indexed starting at zero
            val year = datePicker.year
            val selectedDate = "$day/$month/$year"
            viewModel.value.setValue(selectedDate)

            val diaryEntryStorage = DiaryEntryStorage(requireContext())
            val existingEntryText = diaryEntryStorage.getEntry(selectedDate)
            viewModel.existingEntry.setValue(existingEntryText) // set the existing entry text
            viewModel.value.setValue(selectedDate)

            // automatically navigate to the diary entry page when next button is clicked
            (activity as MainActivity).findViewById<ViewPager2>(R.id.pager).currentItem = 1
        }
        return view
    }
}