package com.example.diaryentryandroidapp;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

class EntriesAdapter(private val entries: List<Pair<String, String>>) :
    RecyclerView.Adapter<EntriesAdapter.ViewHolder>() {

    // One ViewHolder class that can handle both types of views
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateHeader: TextView = itemView.findViewById(R.id.dateHeader);
        val entryText: TextView = itemView.findViewById(R.id.entryText);
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.entry_item, parent, false);
        return ViewHolder(view);
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (date, text) = entries[position];
        holder.dateHeader.text = date;
        holder.entryText.text = text;
    }

    override fun getItemCount() = entries.size;

    override fun getItemViewType(position: Int): Int {
        // Assuming that if the entry text is empty, it's a date header
        return if (entries[position].second.isEmpty()) 1 else 2;
    }
}
