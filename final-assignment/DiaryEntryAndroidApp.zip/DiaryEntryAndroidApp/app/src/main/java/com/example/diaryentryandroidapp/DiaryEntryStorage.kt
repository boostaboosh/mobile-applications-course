package com.example.diaryentryandroidapp

import android.content.Context

class DiaryEntryStorage(context: Context) {
    /* When a new instance of a class is created, the data is not lost every time the app runs
     * because the data is stored in memory.
     * When the app is closed, the data is saved to disk so that it can be retrieved
     * when the app is opened again.
     * This is done using storage mechanisms such as shared preferences.
     */
    private val sharedPreferences = context.getSharedPreferences("DiaryEntries", Context.MODE_PRIVATE)

    fun saveEntry(date: String, entry: String) {
        sharedPreferences.edit().putString(date, entry).apply()
    }

    fun deleteEntry(date: String) {
        sharedPreferences.edit().remove(date).apply()
    }

    fun getEntry(date: String): String {
        return sharedPreferences.getString(date, "") ?: ""
    }

    fun getAllEntries(): Map<String, String> {
        return sharedPreferences.all.filterValues { it is String } as Map<String, String>
    }
}