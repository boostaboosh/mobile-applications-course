package com.example.diaryentryandroidapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DiaryEntryFragment : Fragment() {
    lateinit var viewModel: MyViewModel
    private var selectedDate: String = "" // selectedDate is defined at the class level
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        viewModel = activity?.run {
            ViewModelProvider(this)[MyViewModel::class.java]
        } ?: throw Exception("Invalid Activity")
        val view = inflater.inflate(R.layout.diary_entry_fragment, container, false)

        val selectedDateView = view.findViewById<TextView>(R.id.selectedDate)
        // make a variable which stores the selectedDate
        val selectedDateValueObserver = Observer<String> { newValue ->
            selectedDate = newValue // Update selectedDate here, which is defined at a class level, here
            selectedDateView.text = "Selected date: $selectedDate"
        }
        viewModel.value.observe(viewLifecycleOwner, selectedDateValueObserver) // observes changes to the value of the selected date in the view model
                                                                               // and updates the selected date observer variable value here when it changes
        // selectedDateValueObserver is set before saveButton click listener because this updates selectedDate,
        // and I want to ensure this happens before I try to save the selectedDate when the saveButton is clicked.

        val diaryText = view.findViewById<EditText>(R.id.diaryText)
        // observe existingEntry and set the text of diaryText when it changes
        viewModel.existingEntry.observe(viewLifecycleOwner, Observer { entryText ->
            diaryText.setText(entryText)
        })
        // set the diary text to that of the current date entry if it exists when the app launches
        val currentDate = SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(Date())
        val diaryEntryStorage = DiaryEntryStorage(requireContext())
        val entryText = diaryEntryStorage.getEntry(currentDate)
        diaryText.setText(entryText)

        val saveButton = view.findViewById<Button>(R.id.saveButton)
        saveButton.setOnClickListener {
            val diaryEntry = diaryText.text.toString()
            val diaryEntryStorage = DiaryEntryStorage(requireContext())
            // If an empty entry is saved the entry for that date should be deleted
            if (diaryEntry.isBlank()) {
                diaryEntryStorage.deleteEntry(selectedDate)
            } else {
                // only save the entry if the user actually wrote an entry, i.e., text !blank
                diaryEntryStorage.saveEntry(selectedDate, diaryEntry)
            }
            // update the MyViewModel instance shared between fragments when a new entry is saved,
            // so that DiaryHistoryFragment can updates its list of displayed entries
            viewModel.diaryEntriesUpdated.value = true

            // automatically navigate to the diary history page when save button is clicked
            (activity as MainActivity).findViewById<ViewPager2>(R.id.pager).currentItem = 2
        }

        val clearButton = view.findViewById<Button>(R.id.clearButton)
        clearButton.setOnClickListener {
            diaryText.text.clear()
        }

        val deleteButton = view.findViewById<Button>(R.id.deleteButton)
        deleteButton.setOnClickListener {
            val diaryEntryStorage = DiaryEntryStorage(requireContext())
            diaryEntryStorage.deleteEntry(selectedDate)
            viewModel.diaryEntriesUpdated.value = true
        }

        return view
    }
}