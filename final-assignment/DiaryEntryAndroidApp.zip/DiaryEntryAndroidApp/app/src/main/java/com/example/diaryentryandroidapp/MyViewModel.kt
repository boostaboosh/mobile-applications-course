package com.example.diaryentryandroidapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.util.Calendar

/**
 * MyViewModel is used to share data between different fragments.
 * It holds the selected date and whether the diary entries have been updated (diaryEntriesUpdated).
 * It also holds the existing entry (existingEntry),
 * which is used to populate the diary entry text when a date that already has an entry is selected.
 */
class MyViewModel : ViewModel() {
    val selectedDate = MutableLiveData<String>()
    // The selectedDate is a MutableLiveData object, so you can't directly assign a String value to it.
    // Instead, the String value is assigned to the value property of the MutableLiveData
    val value: MutableLiveData<String>
        get() = selectedDate
    init {
        // set the default (starting value of) selected date to be the current date
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH) + 1 // +1 because months indexed starting at zero
        val year = calendar.get(Calendar.YEAR)
        selectedDate.value = "$day/$month/$year"
    }

    val diaryEntriesUpdated = MutableLiveData<Boolean>()

    val existingEntry = MutableLiveData<String>()
}