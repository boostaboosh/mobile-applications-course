package com.example.diaryentryandroidapp

import android.app.DatePickerDialog
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SearchView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar

class DiaryHistoryFragment : Fragment() {
    private lateinit var viewModel: MyViewModel
    @RequiresApi(Build.VERSION_CODES.O) // indicate that methods in this class require API level 26 or higher (i.e., Android Oreo) to function properly
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        viewModel = activity?.run { ViewModelProvider(this)[MyViewModel::class.java]
        } ?: throw Exception("Invalid Activity")
        val view = inflater.inflate(R.layout.diary_history_fragment, container, false)
        val entriesRecyclerView: RecyclerView = view.findViewById(R.id.entriesRecyclerView)
        entriesRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Create a new instance of DiaryEntryStorage class and assign it to diaryEntryStorage variable
        val diaryEntryStorage = DiaryEntryStorage(requireContext())

        /**
         * Display all entries in entry storage in chronological order starting with newest
         */
        fun displayAllEntries() {
            // The saved entries are available in a list called savedEntries
            val savedEntries = diaryEntryStorage.getAllEntries() // update list of saved entries with potential new/removed entries
            // Sort the entries by date recency before displaying them
            val sortedEntries = savedEntries.entries.sortedByDescending {// Sort the entries by date recency before displaying them
                LocalDate.parse(it.key, DateTimeFormatter.ofPattern("d/M/yyyy")) // Convert the date strings to LocalDate objects and sort them
            }

            val entriesWithDateHeaders = mutableListOf<Pair<String, String>>()
            for (entry in sortedEntries) {
                val entryDate = LocalDate.parse(entry.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
                val formattedDate = entryDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                val entryText = entry.value
                entriesWithDateHeaders.add(Pair(formattedDate, entryText))
            }

            // creates a new instance of EntriesAdapter with the sorted entries, i.e., displays the sorted entries
            entriesRecyclerView.adapter = EntriesAdapter(entriesWithDateHeaders)
        }

        displayAllEntries() // display all diary entries when app starts


        // update the entries display whenever a new entry is saved by observing the diaryEntriesUpdates variable
        viewModel.diaryEntriesUpdated.observe(viewLifecycleOwner, Observer { updated ->
            if (updated) {
                val savedEntries = diaryEntryStorage.getAllEntries() // update list of saved entries with potential new/removed entries
                val sortedEntries = savedEntries.entries.sortedByDescending { // Sort the entries by date recency before displaying them
                    // Convert the date strings to LocalDate objects and sort them
                    LocalDate.parse(it.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
                }
                displayAllEntries()

                // scroll to the edited entry in DiaryHistoryFragment
                val position = sortedEntries.indexOfFirst { it.key == viewModel.selectedDate.value } // finds the position of the edited entry in the entries list
                entriesRecyclerView.scrollToPosition(position) // scrollToPosition(position) then scrolls the RecyclerView to that position

                viewModel.diaryEntriesUpdated.value = false // reset the value of diaryEntriesUpdated
                                                            // to false after updating the diary entries
                                                            // display to avoid unnecessary updates
            }
        })

        /**
         * The filterDiaryEntries method gets all diary entries,
         * filters the entries by the selected date,
         * and updates the RecyclerView adapter with the filtered entries.
         */
        fun filterDiaryEntries(year: Int, month: Int) {
            val allEntries = diaryEntryStorage.getAllEntries()
            val filteredEntries = allEntries.filterKeys {
                val entryDate = LocalDate.parse(it, DateTimeFormatter.ofPattern("d/M/yyyy"))
                entryDate.year == year && entryDate.monthValue == month
            }

            val sortedEntries = filteredEntries.entries.sortedByDescending {
                LocalDate.parse(it.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
            }

            val entriesWithDateHeaders = mutableListOf<Pair<String, String>>()
            for (entry in sortedEntries) {
                val entryDate = LocalDate.parse(entry.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
                val formattedDate = entryDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                val entryText = entry.value
                entriesWithDateHeaders.add(Pair(formattedDate, entryText))
            }

            // creates a new instance of EntriesAdapter with the sorted entries, i.e., displays the sorted entries
            entriesRecyclerView.adapter = EntriesAdapter(entriesWithDateHeaders)
        }


        // add a click event listener to the filter button
        val filterButton: Button = view.findViewById(R.id.filterButton)
        filterButton.setOnClickListener {
            if (filterButton.text == "Filter by month & year") {
                val datePickerDialog = DatePickerDialog(
                    requireContext(),
                    { _, year, month, _ ->
                        filterDiaryEntries(year, month + 1)
                        filterButton.text = "Clear filter"
                    },
                    Calendar.getInstance().get(Calendar.YEAR),
                    Calendar.getInstance().get(Calendar.MONTH),
                    Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                )
                // Show the DatePickerDialog when the filter button is pressed
                datePickerDialog.show()
            } else { // if button text is clear filter
                displayAllEntries()
                filterButton.text = "Filter by month & year"
            }
        }

        /**
         * Get all diary entries,
         * filter the entries by the search query,
         * and update the RecyclerView adapter with the filtered entries.
         */
        fun filterEntriesBySearchQuery(query: String) {
            val allEntries = diaryEntryStorage.getAllEntries()
            val filteredEntries = allEntries.filterValues { it.contains(query, ignoreCase = true) }

            val sortedEntries = filteredEntries.entries.sortedByDescending {
                LocalDate.parse(it.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
            }

            val entriesWithDateHeaders = mutableListOf<Pair<String, String>>()
            for (entry in sortedEntries) {
                val entryDate = LocalDate.parse(entry.key, DateTimeFormatter.ofPattern("d/M/yyyy"))
                val formattedDate = entryDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                val entryText = entry.value
                entriesWithDateHeaders.add(Pair(formattedDate, entryText))
            }

            // creates a new instance of EntriesAdapter with the sorted entries, i.e., displays the sorted entries
            entriesRecyclerView.adapter = EntriesAdapter(entriesWithDateHeaders)
        }

        /**
         * Filter the entries by the search query when the user submits a search.
         */
        val searchView: SearchView = view.findViewById(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                filterEntriesBySearchQuery(query)
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                // update the search results in real-time while the user is typing
                filterEntriesBySearchQuery(newText)
                return false
            }
        })

        return view;
    }
}