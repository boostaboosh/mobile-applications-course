# DiaryEntryAndroidApp
In brief, the application is an app to input and display entries into a diary. 
The app will have three screens: one for selecting the date, the second to enter the diary entry text, and the third to display stored diary entries. 
The three screens are to be implemented using Fragments within an Activity.
