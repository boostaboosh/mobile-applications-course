package com.example.diaryentryandroidapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // setting the view
//        val toolbar = findViewById<Toolbar>(R.id.toolbar) // initialise the toolbar by loading its
                                                          // resource and passing it into a Toolbar
                                                          // object
//        setSupportActionBar(toolbar)

        // set up the tabs we need for each of the fragments
        val tabLayout = findViewById<TabLayout>(R.id.tab_layout)
        tabLayout.addTab(tabLayout.newTab().setText(R.string.date_selection_tab_page1))
        tabLayout.addTab(tabLayout.newTab().setText(R.string.diary_entry_tab_page2))
        tabLayout.addTab(tabLayout.newTab().setText(R.string.diary_history_tab_page3))
        tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        // link the ViewPager2 area in the layout with an instance of the adaptor class defined above
        val viewPager = findViewById<ViewPager2>(R.id.pager)
        val adapter = PageAdapter(this, 3)
        viewPager.setAdapter(adapter)

        // synchronize tab selection with the ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = resources.getString(R.string.date_selection_tab_page1)
                1 -> tab.text = resources.getString(R.string.diary_entry_tab_page2)
                2 -> tab.text = resources.getString(R.string.diary_history_tab_page3)
            }
        }.attach() // attach() method is called to attach the mediator to the TabLayout and ViewPager2
    }
}